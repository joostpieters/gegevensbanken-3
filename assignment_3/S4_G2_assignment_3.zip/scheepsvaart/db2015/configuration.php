<?php
$config = array(
    'dsn' => 'mysql:host=localhost;dbname=shipping;charset=utf8',
    'username' => 'root',
    'password' => ''
);
?>